#ifndef UNTITLED10_GLOBAL_H
#define UNTITLED10_GLOBAL_H
#define WIDTH 800
#define HEIGHT 600
#define CELL_SIZE 30


#endif
